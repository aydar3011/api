-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Июн 19 2020 г., 00:49
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `m98690j5_mybd`
--

-- --------------------------------------------------------

--
-- Структура таблицы `api_films`
--
-- Создание: Июн 18 2020 г., 21:28
-- Последнее обновление: Июн 18 2020 г., 21:44
--

DROP TABLE IF EXISTS `api_films`;
CREATE TABLE `api_films` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `title_rus` varchar(100) NOT NULL,
  `description_rus` varchar(400) NOT NULL,
  `imdb` decimal(4,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `api_films`
--

INSERT INTO `api_films` (`id`, `title`, `title_rus`, `description_rus`, `imdb`) VALUES
(1, 'Castle in the Sky', 'Небесный замок Лапута', 'Альтернативная реальность, соответствующая началу XX века. В руках девочки по имени Сита находится Летающий Камень. За ним охотятся агенты правительства и пираты, потому что Камень представляет огромную ценность. Пытаясь скрыться от преследователей, Сита встречает Падзу, своего ровесника, работающего в шахтерском городке. Вместе дети выясняют, что Камень — ключ к таинственному летающему острову Ла', '8.00'),
(2, 'Grave of the Fireflies', 'Могила светлячков', 'Последние дни Второй мировой войны, американская авиация бомбит беззащитные японские города. В водоворот каждодневного кошмара попадают 14-летний Сэйта и его сестренка Сэцуко — потеряв близких, они остались совсем одни. Мальчик в одночасье становится взрослым и осознаёт, что от него зависит жизнь маленькой сестры.', '8.50'),
(3, 'My Neighbor Totoro', 'Мой сосед Тоторо', 'Переехав в деревню, две маленькие сестры, старшая Сацуки и младшая Мэй, знакомятся с лесным духом, которого Мэй называет Тоторо. Подружившись с девочками, Тоторо не только устраивает им воздушную экскурсию по своим владениям, но и помогает повидаться с мамой, которая лежит в больнице.', '8.20'),
(4, 'Kiki\'s Delivery Service', 'Ведьмина служба доставки', 'Молодая ведьма Кики по достижении 13 лет должна прожить определённое время среди людей. Кики вместе со своим котом Дзидзи отправляется в город, где знакомится с добрым пекарем, который помогает ей начать собственное дело — экстренную службу доставки. Новая работа знакомит Кики со множеством различных людей и предоставляет возможность обрести новых друзей и совершать массу всевозможных проделок.', '7.80'),
(5, 'Only Yesterday', 'Ещё вчера', 'Таэко вспоминает времена, когда она была маленькой и училась в школе в далеком 1966 году. Повествование постоянно скачет назад и вперед между двумя временными периодами с ностальгией и прекрасными горными пейзажами, в то время как Таэко расставляет по полочкам свои воспоминания и пытается принять трудное решение о будущем.', '7.70'),
(6, 'Porco Rosso', 'Порко Россо', 'Марко Пагот, отважный пилот и герой Первой мировой войны, потерял веру в человечество. Это стало проклятием, которое превратило его в человекообразную свинью, и теперь Марко известен как Порко Россо. Порко занялся охотой на воздушных пиратов, грабивших суда и яхты, но однажды ему самому предстоит стать мишенью. Сможет ли он избежать преследования и вернуть человеческий облик?', '7.70'),
(7, 'Pom Poko', 'Помпоко: Война тануки', 'Современная Япония, западные окраины Токио. Люди застраивают леса и холмы, которые раньше принадлежали тануки — енотовидным собакам. Тануки начинают героическую, но обреченную войну за выживание. Для этого они возрождают древнее искусство превращения. С его помощью они могут превращаться даже в людей.', '7.30'),
(8, 'Whisper of the Heart', 'Шёпот сердца', 'Сидзуку, взяв очередную книгу в библиотеке, случайно заметила, что до нее эту книгу взял некий Сейдзи. И это произошло не впервые, этот Сейдзи читал и другие книги, которые понравились ей. Заинтересовавшись, Сидзуку решила узнать — кто он, этот читающий принц?', '7.90'),
(9, 'Princess Mononoke', 'Принцесса Мононоке', 'Убив вепря, юный принц Аситака навлек на себя смертельное проклятие. Старая знахарка предсказала, что только он сам способен изменить свою судьбу, и отважный воин отправился в опасное путешествие. Так он оказался в загадочной стране, где люди под предводительством злой госпожи Эбоси воевали с обитателями леса: духами, демонами и гигантскими существами, каких Аситака раньше никогда не видел.', '8.40'),
(10, 'My Neighbors the Yamadas', 'Наши соседи Ямада', 'Ямада — обычная семья: папа, мама, бабушка, сын Нобору и дочка Ноноко. Но каждый день с ними происходит что-нибудь занятное: то Ноноко в супермаркете оставят, то папа с мамой устраивают сложнопостановочные бои за право взять пульт от телевизора, то бабушка затеет приготовление странного блюда бефстроганов.', '7.20'),
(11, 'Spirited Away', 'Унесённые призраками', 'Тихиро с мамой и папой переезжают в новый дом. Заблудившись по дороге, они оказываются в странном пустынном городе, где их ждет великолепный пир. Родители с жадностью набрасываются на еду и к ужасу девочки превращаются в свиней, став пленниками злой колдуньи Юбабы. Теперь, оказавшись одна среди волшебных существ и загадочных видений, Тихиро должна придумать, как избавить своих родителей от чар ков', '8.60'),
(12, 'The Cat Returns', 'Возвращение кота', 'В разгар дня на оживленной улице юная Хару храбро выхватывает из-под колес грузовика очаровательного кота. К ее великому удивлению, кот встает на задние лапы и благодарит Хару на человеческом языке. Оказывается, перед ней принц из загадочного Кошачьего царства, и теперь могущественный Кошачий царь хочет женить его на отважной спасительнице.', '7.20'),
(13, 'Howl\'s Moving Castle', 'Ходячий замок', 'Злая ведьма заточила 18-летнюю Софи в тело старухи. Девушка-бабушка бежит из города куда глаза глядят и встречает удивительный дом на ножках, где знакомится с могущественным волшебником Хаулом и демоном Кальцифером. Кальцифер должен служить Хаулу по договору, условия которого он не может разглашать. Девушка и демон решают помочь друг другу избавиться от злых чар.', '8.20'),
(14, 'Tales from Earthsea', 'Сказания Земноморья', 'Земноморье в опасности, мир волшебства на грани исчезновения. Вселенское равновесие нарушено: драконы, обитающие в западном пределе сказочной страны, неожиданно появляются на востоке во владениях людей. Верховный маг Гед отправляется на поиски первопричины беды. В пути он встречает Аррена, принца Энлада, который после убийства отца бежит из родного края, преследуемый тенью.', '6.50'),
(15, 'Ponyo', 'Рыбка Поньо на утёсе', 'Маленькая любопытная рыбка Поньо — дочь колдуна и прекрасной морской богини уплывает из дома, чтобы понаблюдать за жизнью людей. Поньо застревает в банке и оказывается выброшенной на берег. Ее подбирает пятилетний Сооскэ. Малыши привязываются друг к другу. И теперь у Поньо только одно желание — стать человеком!', '7.70'),
(16, 'Arrietty', 'Ариэтти из страны лилипутов', 'История маленьких существ, которые живут рядом с людьми, одалживая вещи по чуть-чуть. Их существование хранится в секрете, но юная Ариэтти нарушает запрет. Её обнаруживает 14-летний Сё, и они становятся лучшими друзьями.', '7.60'),
(17, 'From Up on Poppy Hill', 'Со склонов Кокурико', '1963 год, близ Иокогамы. Отец Уми Мацудзаки — командир корабля, погиб 10 лет назад во время Корейской войны, когда та была совсем маленькой. Пока её мама в отъезде, девочке приходится вести хозяйство, в частности, не забывать каждое утро поднимать флажки — такое правило установил отец, чтобы видеть с моря, что его ждут дома.', '7.40'),
(18, 'The Wind Rises', 'Ветер крепчает', 'Мальчик Дзиро мечтает о полетах и красивых самолетах, способных обогнать ветер. Вот только пилотом ему не стать — он с рождения близорук. Но Дзиро не расстается с мечтой о небе, он начинает придумывать идеальный самолет и со временем становится одним из лучших авиаконструкторов мира. На пути к успеху он не только встретит много интересных людей, переживет Великое землетрясение в Токио и жестокие в', '7.80'),
(19, 'The Tale of the Princess Kaguya', 'Сказание о принцессе Кагуя', 'Старик, зарабатывающий на жизнь продажей бамбука, как-то раз находит в бамбуковом лесу маленькую девочку размером с палец, которая оказывается принцессой по имени Кагуя.', '8.00'),
(20, 'When Marnie Was There', 'Воспоминания о Марни', '12-летняя Анна — замкнутая и необщительная девочка. У неё нет друзей, и единственная её отдушина — это рисование. Из-за слабого здоровья Анну отправляют на лето в небольшой городок в Хоккайдо. Там она встречает Марни — девочку, живущую в большом богатом доме на отмели. Постепенно они становятся хорошими друзьями.', '7.70');

-- --------------------------------------------------------

--
-- Структура таблицы `auth_group`
--
-- Создание: Июн 18 2020 г., 21:28
--

DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `auth_group_permissions`
--
-- Создание: Июн 18 2020 г., 21:27
--

DROP TABLE IF EXISTS `auth_group_permissions`;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `auth_permission`
--
-- Создание: Июн 18 2020 г., 21:28
-- Последнее обновление: Июн 18 2020 г., 21:28
--

DROP TABLE IF EXISTS `auth_permission`;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add films', 7, 'add_films'),
(26, 'Can change films', 7, 'change_films'),
(27, 'Can delete films', 7, 'delete_films'),
(28, 'Can view films', 7, 'view_films');

-- --------------------------------------------------------

--
-- Структура таблицы `auth_user`
--
-- Создание: Июн 18 2020 г., 21:28
-- Последнее обновление: Июн 18 2020 г., 21:29
--

DROP TABLE IF EXISTS `auth_user`;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `auth_user`
--

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(1, 'pbkdf2_sha256$180000$RoGgzGmdkdN5$/7Z7er2kyyUpzE7FlyWA25uu4e+sI/fS1NxsuveEo4o=', NULL, 1, 'admin', '', '', 'adm@adm.ru', 1, 1, '2020-06-18 21:29:09.652985');

-- --------------------------------------------------------

--
-- Структура таблицы `auth_user_groups`
--
-- Создание: Июн 18 2020 г., 21:27
--

DROP TABLE IF EXISTS `auth_user_groups`;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `auth_user_user_permissions`
--
-- Создание: Июн 18 2020 г., 21:27
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `django_admin_log`
--
-- Создание: Июн 18 2020 г., 21:27
--

DROP TABLE IF EXISTS `django_admin_log`;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `django_content_type`
--
-- Создание: Июн 18 2020 г., 21:28
-- Последнее обновление: Июн 18 2020 г., 21:28
--

DROP TABLE IF EXISTS `django_content_type`;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(7, 'api', 'films'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(6, 'sessions', 'session');

-- --------------------------------------------------------

--
-- Структура таблицы `django_migrations`
--
-- Создание: Июн 18 2020 г., 21:27
-- Последнее обновление: Июн 18 2020 г., 21:28
--

DROP TABLE IF EXISTS `django_migrations`;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2020-06-18 21:27:52.988232'),
(2, 'auth', '0001_initial', '2020-06-18 21:27:57.642519'),
(3, 'admin', '0001_initial', '2020-06-18 21:27:59.265071'),
(4, 'admin', '0002_logentry_remove_auto_add', '2020-06-18 21:27:59.309995'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2020-06-18 21:27:59.326777'),
(6, 'api', '0001_initial', '2020-06-18 21:28:00.147253'),
(7, 'api', '0002_auto_20200618_2309', '2020-06-18 21:28:00.151547'),
(8, 'contenttypes', '0002_remove_content_type_name', '2020-06-18 21:28:00.234109'),
(9, 'auth', '0002_alter_permission_name_max_length', '2020-06-18 21:28:00.256716'),
(10, 'auth', '0003_alter_user_email_max_length', '2020-06-18 21:28:00.286486'),
(11, 'auth', '0004_alter_user_username_opts', '2020-06-18 21:28:00.295648'),
(12, 'auth', '0005_alter_user_last_login_null', '2020-06-18 21:28:00.340342'),
(13, 'auth', '0006_require_contenttypes_0002', '2020-06-18 21:28:00.341396'),
(14, 'auth', '0007_alter_validators_add_error_messages', '2020-06-18 21:28:00.349810'),
(15, 'auth', '0008_alter_user_username_max_length', '2020-06-18 21:28:00.374719'),
(16, 'auth', '0009_alter_user_last_name_max_length', '2020-06-18 21:28:00.401623'),
(17, 'auth', '0010_alter_group_name_max_length', '2020-06-18 21:28:00.427611'),
(18, 'auth', '0011_update_proxy_permissions', '2020-06-18 21:28:00.446260'),
(19, 'sessions', '0001_initial', '2020-06-18 21:28:00.964323');

-- --------------------------------------------------------

--
-- Структура таблицы `django_session`
--
-- Создание: Июн 18 2020 г., 21:28
--

DROP TABLE IF EXISTS `django_session`;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `api_films`
--
ALTER TABLE `api_films`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Индексы таблицы `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Индексы таблицы `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Индексы таблицы `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Индексы таблицы `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Индексы таблицы `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Индексы таблицы `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Индексы таблицы `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Индексы таблицы `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `api_films`
--
ALTER TABLE `api_films`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT для таблицы `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT для таблицы `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Ограничения внешнего ключа таблицы `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Ограничения внешнего ключа таблицы `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Ограничения внешнего ключа таблицы `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Ограничения внешнего ключа таблицы `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
